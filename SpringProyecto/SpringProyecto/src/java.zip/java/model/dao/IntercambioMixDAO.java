/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import model.pojo.Intercambio;
import model.pojo.IntercambioMix;
import model.pojo.Invitados;
import model.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author Z420
 */
public class IntercambioMixDAO {

    public static void makeMIX(int id) {
        List<String> Correos = new ArrayList<String>();
        List<Invitados> invit = null;
        try{
            Session sesion = HibernateUtil.getSessionFactory().openSession();
            Query query = sesion.createQuery("SELECT u FROM Invitados u WHERE u.idIntercambio='"+id+"' AND status='aceptado'");
            invit = query.list();
            if(invit != null){
                Iterator<Invitados> invitIterator = invit.iterator();
                while(invitIterator.hasNext()) {
                    Invitados item = invitIterator.next();
                    Correos.add(item.getEmailUser());
                 }
                //Aqui ya esta una lista de correos
                //falta ahora desordenarla
                Collections.shuffle(Correos); //Metodo para desordenar listas
                IntercambioMixDAO.registrarMIX(Correos,id);
                sesion.close();
            }else{
                sesion.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private static void registrarMIX(List<String> Correos, int id_inter) {
        SessionFactory sf= null;
        Session sesion = null;
        Transaction tx = null;
        try{
            sf = HibernateUtil.getSessionFactory();
            sesion = sf.openSession();
            tx = sesion.beginTransaction();
            IntercambioMix interMix = new IntercambioMix();
            interMix.setIdIntercambio(id_inter);
            //Pasamos list a string coma separate

            String random = String.join(",", Correos);
            interMix.setRandom(random);
            sesion.save(interMix);
            tx.commit();
            sesion.close();
        }catch(Exception ex){
            tx.rollback();
            throw new RuntimeException("No se pudo guardar el MIX");
        }
    }

    public static int isMixed(int id) {
        SessionFactory sf= null;
        Session sesion = null;
        Transaction tx = null;
        sf = HibernateUtil.getSessionFactory();
        sesion = sf.openSession();
        IntercambioMix inter = (IntercambioMix)sesion.createQuery("SELECT u FROM IntercambioMix u WHERE u.idIntercambio='"+id+"'").uniqueResult();
        sesion.close();
        if(inter != null){
            return 1;
        }else{
            return 0;
        }
    }

    public static List<String> getMIX(Integer idIntercambio) {
        List<String> mix = new ArrayList<String>();
        SessionFactory sf= null;
        Session sesion = null;
        Transaction tx = null;
        sf = HibernateUtil.getSessionFactory();
        sesion = sf.openSession();
        IntercambioMix inter = (IntercambioMix)sesion.createQuery("SELECT u FROM IntercambioMix u WHERE u.idIntercambio='"+idIntercambio+"'").uniqueResult();
        sesion.close();
        if(inter != null){
            //Aqui regreso random
            String par = "";
            String[] parts = inter.getRandom().split(",");
            for(int i=0;i<parts.length;i++){
                if(i==parts.length-1){
                    par = parts[i] + "->" +parts[0];
                }else{
                   par = parts[i] + "->" +parts[i+1]; 
                }
                mix.add(par);
            }
            return mix;
        }else{
            return null;
        }
    }
    
    /*
    String string = "004-034556";
String[] parts = string.split("-");
String part1 = parts[0]; // 004
String part2 = parts[1]; // 034556
    */
}
