/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.dao.InvitadosDAO;
import model.dao.UsuarioDAO;
import model.pojo.Usuario;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

/**
 *
 * @author Z420
 */
public class SendInvitacionController implements Controller{

    @Override
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
         ModelAndView mv = new ModelAndView("logged/sendInvitacion"); 
        try{
            HttpSession session = request.getSession(true);
            String email = (String) session.getAttribute("email");
            Usuario user = UsuarioDAO.getDataUser(email);
            if(user != null){
                System.out.println("[ INFO ] SendInvitacionController.java Cargado");
                int notificacion = InvitadosDAO.getMisInvitacionesNumero(email);
                String clave = "";
                if(request.getParameter("clave")!= null){
                    clave = (String) request.getParameter("clave");
                }
                System.out.print("[ INFO ] CLAVE: "+clave);
                mv.addObject("clave",clave);
                mv.addObject("notificacion",notificacion);
                return mv;
            }else{
                System.out.println("[ ERROR ] No hay sesión activa");
                mv = new ModelAndView("sorry"); 
                mv.addObject("mensaje","Lo siento, usted no tiene una sesion activa.");
                return mv;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
